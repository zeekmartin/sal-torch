"""Architecture auto-detection for SAL."""
from __future__ import annotations
from dataclasses import dataclass

class SALArchitectureError(Exception):
    pass

@dataclass
class ArchInfo:
    model_type: str
    num_layers: int
    num_heads: int
    head_dim: int
    hidden_size: int
    attention_pattern: str

    @property
    def total_heads(self) -> int:
        return self.num_layers * self.num_heads

def _standard_arch(model_type, config, pattern):
    nl = getattr(config, 'num_hidden_layers', getattr(config, 'n_layer', getattr(config, 'n_layers', None)))
    nh = getattr(config, 'num_attention_heads', getattr(config, 'n_head', getattr(config, 'n_heads', None)))
    hs = getattr(config, 'hidden_size', getattr(config, 'n_embd', getattr(config, 'dim', None)))
    hd = getattr(config, 'head_dim', hs // nh if hs and nh else None)
    if nl is None or nh is None or hs is None:
        raise SALArchitectureError(f"Cannot extract arch params for '{model_type}'")
    return ArchInfo(model_type=model_type, num_layers=nl, num_heads=nh, head_dim=hd, hidden_size=hs, attention_pattern=pattern)

_REGISTRY = {
    "llama": "model.layers.{}.self_attn",
    "mistral": "model.layers.{}.self_attn",
    "gpt2": "transformer.h.{}.attn",
    "bert": "encoder.layer.{}.attention.self",
    "roberta": "encoder.layer.{}.attention.self",
    "distilbert": "distilbert.transformer.layer.{}.attention",
    "vit": "encoder.layer.{}.attention.attention",
    "phi": "model.layers.{}.self_attn",
    "phi3": "model.layers.{}.self_attn",
    "gemma": "model.layers.{}.self_attn",
    "gemma2": "model.layers.{}.self_attn",
    "qwen2": "model.layers.{}.self_attn",
}

def detect_architecture(model) -> ArchInfo:
    config = getattr(model, 'config', None)
    if config is None:
        raise SALArchitectureError("Model has no .config. Use SALConfig manually.")
    model_type = getattr(config, 'model_type', None)
    if model_type is None:
        raise SALArchitectureError("Model config has no model_type. Use SALConfig manually.")
    pattern = _REGISTRY.get(model_type)
    if pattern is None:
        raise SALArchitectureError(f"'{model_type}' not supported. Supported: {sorted(_REGISTRY.keys())}")
    return _standard_arch(model_type, config, pattern)

def supported_architectures() -> list[str]:
    return sorted(_REGISTRY.keys())
