"""Head masking mechanism for SAL."""
from __future__ import annotations
import logging, random
from typing import Optional
import torch, torch.nn as nn
from sal.config import SALConfig

logger = logging.getLogger(__name__)

class HeadMasker:
    def __init__(self, model: nn.Module, config: SALConfig, seed: Optional[int] = None):
        self.model = model
        self.config = config
        self.rng = random.Random(seed)
        self._hooks: list = []
        self._masks: dict[int, torch.Tensor] = {}
        self._attention_modules: list[nn.Module] = []
        self._active = False
        self._step_count = 0
        self._prune_events = 0

    def install(self):
        if self._hooks:
            raise RuntimeError("HeadMasker already installed. Call remove() first.")
        self._attention_modules = self._find_attention_modules()
        if len(self._attention_modules) != self.config.num_layers:
            raise ValueError(f"Found {len(self._attention_modules)} attn modules, config says {self.config.num_layers}")
        device = next(self.model.parameters()).device
        for layer_idx, attn_mod in enumerate(self._attention_modules):
            out_proj = self._get_output_projection(attn_mod)
            if out_proj is None:
                raise ValueError(f"No output projection at layer {layer_idx}")
            hook = out_proj.register_forward_hook(self._make_hook(layer_idx))
            self._hooks.append(hook)
            self._masks[layer_idx] = torch.ones(self.config.num_heads_per_layer, device=device)
        logger.info(f"SAL HeadMasker installed: {len(self._attention_modules)} layers, {self.config.total_heads} heads")

    def remove(self):
        for h in self._hooks:
            h.remove()
        self._hooks.clear(); self._masks.clear(); self._attention_modules.clear()
        self._active = False

    def activate(self):
        if not self._hooks:
            raise RuntimeError("Not installed")
        self._active = True
        self._randomize_masks()

    def deactivate(self):
        self._active = False
        for m in self._masks.values():
            m.fill_(1.0)

    def step(self, global_step: int, total_steps: int):
        self._step_count = global_step
        progress = global_step / max(total_steps, 1)
        in_window = self.config.prune_start_ratio <= progress <= self.config.prune_end_ratio
        if in_window and not self._active:
            self.activate()
        elif not in_window and self._active:
            self.deactivate()
        if self._active and global_step % self.config.prune_interval == 0:
            self._randomize_masks()

    def _randomize_masks(self):
        all_heads = [(l, h) for l in range(self.config.num_layers) for h in range(self.config.num_heads_per_layer)]
        for m in self._masks.values():
            m.fill_(1.0)
        n = self.config.num_heads_to_prune
        if self.config.schedule == "progressive":
            progress = self._step_count / max(1, self._step_count + 1)
            n = max(1, int(n * progress))
        to_prune = self.rng.sample(all_heads, min(n, len(all_heads)))
        for li, hi in to_prune:
            self._masks[li][hi] = 0.0
        self._prune_events += 1

    def _make_hook(self, layer_idx: int):
        def hook_fn(module, input, output):
            if not self._active:
                return output
            mask = self._masks.get(layer_idx)
            if mask is None:
                return output
            head_dim = output.shape[-1] // self.config.num_heads_per_layer
            expanded = mask.repeat_interleave(head_dim)
            return output * expanded.unsqueeze(0).unsqueeze(0)
        return hook_fn

    def _find_attention_modules(self) -> list[nn.Module]:
        if self.config.attention_pattern:
            return self._find_by_pattern(self.config.attention_pattern)
        for pat in ["model.layers.{}.self_attn", "transformer.h.{}.attn",
                     "encoder.layer.{}.attention.self", "distilbert.transformer.layer.{}.attention",
                     "encoder.layer.{}.attention"]:
            mods = self._find_by_pattern(pat)
            if mods:
                return mods
        return []

    def _find_by_pattern(self, pattern: str) -> list[nn.Module]:
        modules = []
        for i in range(1000):
            path = pattern.format(i)
            try:
                mod = self.model
                for attr in path.split("."):
                    mod = mod[int(attr)] if attr.isdigit() else getattr(mod, attr)
                modules.append(mod)
            except (AttributeError, IndexError, TypeError):
                break
        return modules

    @staticmethod
    def _get_output_projection(attn_module: nn.Module) -> Optional[nn.Module]:
        for name in ["o_proj", "out_proj", "dense", "output"]:
            proj = getattr(attn_module, name, None)
            if proj is not None:
                if hasattr(proj, "dense"):
                    return proj.dense
                return proj
        return None

    @property
    def stats(self) -> dict:
        active = sum(m.sum().item() for m in self._masks.values()) if self._masks else 0
        return {"active": self._active, "total_heads": self.config.total_heads,
                "active_heads": int(active), "pruned_heads": self.config.total_heads - int(active),
                "prune_events": self._prune_events, "prune_fraction": self.config.prune_fraction}
