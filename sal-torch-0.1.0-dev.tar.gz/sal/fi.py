"""Fragility Index computation."""
from __future__ import annotations
import logging
from enum import Enum
from typing import Optional
import numpy as np
import torch, torch.nn as nn

logger = logging.getLogger(__name__)

class LayerClass(str, Enum):
    IMMUNE = "IMMUNE"
    BUFFER = "BUFFER"
    CRITICAL = "CRITICAL"

def extract_activation_graph(model: nn.Module, probe_dataset, num_samples: int = 500, batch_size: int = 16) -> np.ndarray:
    model.eval()
    device = next(model.parameters()).device
    head_acts: dict[int, list] = {}
    hooks = []
    out_projs = _find_output_projections(model)
    num_heads = _infer_num_heads(model)
    for li, proj in enumerate(out_projs):
        head_acts[li] = []
        def make_hook(idx):
            def fn(mod, inp, out):
                with torch.no_grad():
                    bs, sl, hid = out.shape
                    hd = hid // num_heads
                    per_head = out.view(bs, sl, num_heads, hd).abs().mean(dim=(0, 1, 3)).cpu()
                    head_acts[idx].append(per_head)
            return fn
        hooks.append(proj.register_forward_hook(make_hook(li)))
    try:
        n = 0
        with torch.no_grad():
            for batch in _iter_data(probe_dataset, batch_size):
                batch = _to_dev(batch, device)
                model(**batch) if isinstance(batch, dict) else model(batch)
                n += batch_size
                if n >= num_samples:
                    break
    finally:
        for h in hooks:
            h.remove()
    all_act = []
    for li in range(len(out_projs)):
        if head_acts[li]:
            all_act.append(torch.stack(head_acts[li]))
    if not all_act:
        total = len(out_projs) * num_heads
        return np.eye(total)
    full = torch.cat(all_act, dim=1).numpy()
    corr = np.corrcoef(full.T)
    corr = np.nan_to_num(corr, nan=0.0)
    np.fill_diagonal(corr, 0.0)
    adj = np.abs(corr)
    thr = np.percentile(adj[adj > 0], 50) if np.any(adj > 0) else 0.1
    adj[adj < thr] = 0.0
    return adj

def compute_fi(adjacency: np.ndarray) -> float:
    n = adjacency.shape[0]
    if n < 2:
        return 0.0
    degrees = np.sum(adjacency, axis=1)
    laplacian = np.diag(degrees) - adjacency
    try:
        evals = np.linalg.eigvalsh(laplacian)
        evals = np.sort(evals)
        l2 = max(evals[1], 0.0) if len(evals) > 1 else 0.0
    except Exception:
        return 1.0
    mx = max(np.max(evals), 1e-10)
    fi = 1.0 - (l2 / mx)
    return float(np.clip(fi, 0.0, 1.0))

def classify_layers(model: nn.Module, adjacency: np.ndarray, num_heads_per_layer: Optional[int] = None,
                    immune_thr: float = 0.01, critical_thr: float = 0.05) -> dict[int, LayerClass]:
    if num_heads_per_layer is None:
        num_heads_per_layer = _infer_num_heads(model)
    total = adjacency.shape[0]
    nl = total // num_heads_per_layer
    base_fi = compute_fi(adjacency)
    if base_fi < 1e-10:
        return {i: LayerClass.IMMUNE for i in range(nl)}
    result = {}
    for li in range(nl):
        s, e = li * num_heads_per_layer, (li + 1) * num_heads_per_layer
        mask = np.ones(total, dtype=bool); mask[s:e] = False
        red_fi = compute_fi(adjacency[np.ix_(mask, mask)])
        delta = abs(red_fi - base_fi) / max(base_fi, 1e-10)
        if delta < immune_thr:
            result[li] = LayerClass.IMMUNE
        elif delta >= critical_thr:
            result[li] = LayerClass.CRITICAL
        else:
            result[li] = LayerClass.BUFFER
    return result

def _find_output_projections(model):
    projs = []
    for name, mod in model.named_modules():
        nl = name.lower()
        if any(p in nl for p in ["o_proj", "out_proj"]) and isinstance(mod, nn.Linear):
            projs.append(mod)
    return projs

def _infer_num_heads(model) -> int:
    cfg = getattr(model, 'config', None)
    if cfg is None:
        raise ValueError("No .config")
    for attr in ["num_attention_heads", "n_head", "n_heads"]:
        v = getattr(cfg, attr, None)
        if v is not None:
            return v
    raise ValueError("Cannot infer num_heads")

def _iter_data(dataset, bs):
    if hasattr(dataset, '__iter__'):
        yield from dataset
    else:
        from torch.utils.data import DataLoader
        yield from DataLoader(dataset, batch_size=bs, shuffle=False)

def _to_dev(batch, device):
    if isinstance(batch, dict):
        return {k: v.to(device) if isinstance(v, torch.Tensor) else v for k, v in batch.items()}
    return batch.to(device) if isinstance(batch, torch.Tensor) else batch
