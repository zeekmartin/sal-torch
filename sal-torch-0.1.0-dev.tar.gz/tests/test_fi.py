"""Tests for FI computation."""
import numpy as np
import pytest
from sal.fi import LayerClass, classify_layers, compute_fi, extract_activation_graph

class TestComputeFI:
    def test_complete_graph(self):
        n = 16
        adj = np.ones((n, n)) - np.eye(n)
        fi = compute_fi(adj)
        assert 0.0 <= fi <= 0.2

    def test_disconnected(self):
        n = 16; adj = np.zeros((n, n))
        adj[:8, :8] = 1.0; adj[8:, 8:] = 1.0
        np.fill_diagonal(adj, 0.0)
        fi = compute_fi(adj)
        assert fi > 0.5

    def test_range(self):
        rng = np.random.RandomState(42)
        for _ in range(20):
            n = rng.randint(4, 32)
            adj = rng.rand(n, n); adj = (adj + adj.T) / 2
            np.fill_diagonal(adj, 0.0)
            fi = compute_fi(adj)
            assert 0.0 <= fi <= 1.0

class TestExtractGraph:
    def test_extraction(self, tiny_model, probe_data):
        adj = extract_activation_graph(tiny_model, probe_data, num_samples=20)
        assert adj.shape == (32, 32)

class TestClassify:
    def test_types(self, tiny_model, probe_data):
        adj = extract_activation_graph(tiny_model, probe_data, num_samples=20)
        lm = classify_layers(tiny_model, adj)
        assert len(lm) == 4
        for c in lm.values():
            assert c in (LayerClass.IMMUNE, LayerClass.BUFFER, LayerClass.CRITICAL)
